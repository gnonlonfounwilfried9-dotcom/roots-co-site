document.documentElement.classList.add('js');

/* ---------- language (persistent across pages) ---------- */
(function(){
  document.querySelectorAll('[data-en]').forEach(el=>el.setAttribute('data-fr', el.textContent));
  document.querySelectorAll('[data-en-ph]').forEach(el=>el.setAttribute('data-fr-ph', el.getAttribute('placeholder')||''));
  function setLang(l){
    document.querySelectorAll('[data-en]').forEach(el=>{ el.textContent = l==='en'? el.getAttribute('data-en'):el.getAttribute('data-fr'); });
    document.querySelectorAll('[data-en-ph]').forEach(el=>{ el.placeholder = l==='en'? el.getAttribute('data-en-ph'):el.getAttribute('data-fr-ph'); });
    document.documentElement.lang=l;
    document.querySelectorAll('#lang button').forEach(b=>b.classList.toggle('on', b.dataset.l===l));
    try{ localStorage.setItem('rootsco_lang', l); }catch(e){}
    window.__setHeroWords && window.__setHeroWords(l);
  }
  window.__setLang=setLang;
  let saved='fr'; try{ saved=localStorage.getItem('rootsco_lang')||'fr'; }catch(e){}
  document.querySelectorAll('#lang button').forEach(b=>b.addEventListener('click',()=>setLang(b.dataset.l)));
  window.addEventListener('DOMContentLoaded',()=>{ if(saved==='en') setLang('en'); });
})();

/* ---------- nav scroll state + progress bar ---------- */
(function(){
  const nav=document.getElementById('nav');
  const bar=document.querySelector('.progress');
  function onScroll(){
    const y=window.scrollY;
    if(nav) nav.classList.toggle('scrolled', y>40);
    if(bar){ const h=document.documentElement.scrollHeight-window.innerHeight; bar.style.width=(h>0?(y/h*100):0)+'%'; }
    const tt=document.querySelector('.totop'); if(tt) tt.classList.toggle('show', y>500);
  }
  window.addEventListener('scroll',onScroll,{passive:true}); onScroll();
})();

/* ---------- mobile menu ---------- */
(function(){
  const b=document.getElementById('burger'), l=document.getElementById('navlinks');
  if(!b||!l) return;
  b.addEventListener('click',()=>{ l.classList.toggle('open'); b.classList.toggle('x'); });
  l.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{ l.classList.remove('open'); b.classList.remove('x'); }));
})();

/* ---------- active nav link ---------- */
(function(){
  const path=(location.pathname.split('/').pop()||'index.html');
  document.querySelectorAll('#navlinks a').forEach(a=>{
    const href=a.getAttribute('href')||'';
    if(href===path || (path==='index.html'&&href==='index.html')) a.classList.add('active');
  });
})();

/* ---------- reveal on scroll ---------- */
(function(){
  const els=document.querySelectorAll('[data-reveal]');
  if(!('IntersectionObserver' in window)){ els.forEach(e=>e.classList.add('is-in')); return; }
  const io=new IntersectionObserver((es)=>{es.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('is-in'); io.unobserve(e.target); } })},{threshold:.12,rootMargin:'0px 0px -6% 0px'});
  els.forEach(e=>io.observe(e));
})();

/* ---------- count up ---------- */
(function(){
  function up(el){
    const target=+el.dataset.count, dur=1500, t0=performance.now();
    function step(t){ const p=Math.min((t-t0)/dur,1); const e=1-Math.pow(1-p,3); el.textContent=Math.round(e*target); if(p<1)requestAnimationFrame(step); }
    requestAnimationFrame(step);
  }
  const io=new IntersectionObserver((es)=>{es.forEach(e=>{ if(e.isIntersecting){ e.target.querySelectorAll('.ct').forEach(up); io.unobserve(e.target); } })},{threshold:.5});
  document.querySelectorAll('.stat,[data-counters]').forEach(s=>io.observe(s));
})();

/* ---------- rotating hero words ---------- */
(function(){
  const el=document.querySelector('.rot'); if(!el) return;
  const setW={fr:(el.dataset.fr||'').split('|'), en:(el.dataset.en||'').split('|')};
  let lang='fr', i=0;
  window.__setHeroWords=function(l){ lang=l; };
  function tick(){
    const arr=setW[lang]&&setW[lang].length?setW[lang]:setW.fr;
    el.style.opacity=0; el.style.transform='translateY(8px)';
    setTimeout(()=>{ el.textContent=arr[i%arr.length]; el.style.transition='opacity .4s,transform .4s'; el.style.opacity=1; el.style.transform='none'; i++; },380);
  }
  tick(); setInterval(tick,2600);
})();

/* ---------- parallax ---------- */
(function(){
  const els=[...document.querySelectorAll('[data-parallax]')];
  if(!els.length) return;
  let ticking=false;
  function upd(){
    const vh=window.innerHeight;
    els.forEach(el=>{
      const speed=parseFloat(el.dataset.parallax)||.15;
      const r=el.getBoundingClientRect();
      const off=(r.top+r.height/2 - vh/2);
      el.style.transform='translate3d(0,'+(off*-speed).toFixed(1)+'px,0)';
    });
    ticking=false;
  }
  window.addEventListener('scroll',()=>{ if(!ticking){ requestAnimationFrame(upd); ticking=true; } },{passive:true});
  window.addEventListener('resize',upd); upd();
})();

/* ---------- tilt on cards ---------- */
(function(){
  if(matchMedia('(hover:none)').matches) return;
  document.querySelectorAll('.tilt').forEach(card=>{
    card.addEventListener('mousemove',e=>{
      const r=card.getBoundingClientRect();
      const x=(e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
      card.style.transform='perspective(800px) rotateX('+(-y*6).toFixed(2)+'deg) rotateY('+(x*6).toFixed(2)+'deg) translateY(-6px)';
    });
    card.addEventListener('mouseleave',()=>{ card.style.transform=''; });
  });
})();

/* ---------- back to top ---------- */
(function(){
  const t=document.querySelector('.totop'); if(t) t.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
})();
